# CSM Ops Analytics Starter

This repo is a **ready-to-use portfolio project** showcasing how a Strategic CSM or CS Ops analyst would track
**response SLAs, funnel health, and value realization**. It’s designed to be **no heavy code**: just CSV + SQL examples + one-page docs you can demo in interviews.

> Owner: Deepanshi Behal • Created: 2025-10-01

## What’s inside
- `data/sample_pipeline.csv` – toy dataset of leads → meetings → proposals → wins, with first-reply time and missed follow-ups.
- `sql/queries.sql` – KPI SQL (same-day reply rate, missed follow-ups %, show rate, cycle metrics).
- `docs/QBR.md` – one-page **QBR-style** summary (before/after KPIs + next-30-day plan).
- `docs/SuccessPlan.md` – one-page **success plan** template (customer goals, 3 KPIs, pilot → scale).

## KPIs we track
- **Same-day reply rate** = % of leads with first_reply_minutes ≤ 1440
- **Missed follow-ups %** = % of records with `followup_missed = 1`
- **Meeting show rate** = shows / meetings
- **Win rate** = wins / leads (or wins / proposals)
- **Cycle hints** = proxy from creation to proposal (can be extended with real timestamps)

## Quick start
1. Open `data/sample_pipeline.csv` in Power BI / Tableau / Excel.
2. Recreate these visuals on one page:
   - SLA tiles: same-day replies %, missed follow-ups %
   - Funnel bars: leads → meetings → shows → proposals → wins
   - Segments: by source, by segment (SMB/Mid/Ent)
3. Use `docs/QBR.md` as your **talk track** (2-minute demo).

## Talking points (interview)
- “I keep **one-page KPIs** visible and improve them with **tiny pilots**.”
- “I prevent dropped balls with **CRM automations** (e.g., Salesforce Flow).”
- “I summarize value in **QBR-ready** slides: outcomes first, next 30 days next.”

## License
MIT
